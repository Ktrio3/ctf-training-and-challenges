Stego Challenges for this week:

Un-Bearable: See bear.jpg (Not in normal flag format. Just text. You'll know it.)

Pretty: Stego challenge found at wcsc.ctf.usf.edu

cats: See cat.zip (Not a txt flag. Recover two pictures!)

hidin': See hidin.jpg (Another hidden image)

secret: ??? 